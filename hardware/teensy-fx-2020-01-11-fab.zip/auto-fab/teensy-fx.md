# PCB layout for teensy fx

\ ![overview](auto-fab/teensy-fx-overview.png)

# Configuration

* 60.1 x 100.1mm
* 1.6 mm FR4, white silkscreen, black mask
* 4 layers, 35um copper
 * layer stackup:
    1. CuTop
    2. CuLayer2
    3. CuLayer3
    4. CuBottom
* generated on 2020-01-11 18:35:16.066280, git version 8ce4f4e
