# PCB layout for teensy fx

\ ![overview](auto-fab/teensy-fx-overview.png)

# Configuration

* 60.1 x 100.1mm
* 1.6 mm FR4, white silkscreen, black mask
* 4 layers, 35um copper
 * layer stackup:
    1. CuTop
    2. CuLayer2
    3. CuLayer3
    4. CuBottom
* generated on 2020-01-12 20:44:59.272542, git version 99c1038
