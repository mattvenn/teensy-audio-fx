# PCB layout for teensy fx

\ ![overview](auto-fab/teensy-fx-overview.png)

# Configuration

* 60.1 x 100.1mm
* 1.6 mm FR4, white silkscreen, black mask
* 4 layers, 35um copper
 * layer stackup:
    1. CuTop
    2. CuLayer2
    3. CuLayer3
    4. CuBottom
* generated on 2020-02-10 12:51:58.277594, git version 54d0841
